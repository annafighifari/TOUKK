<?php
// Koneksi ke database
include("config.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Barang</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        form {
            max-width: 400px;
            margin: auto;
            background: #f9f9f9;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input, button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Tambah Barang Baru</h1>
    <form action="prosestambahbarang.php" method="POST">
        <label for="nama">Nama Barang:</label>
        <input type="text" id="nama" name="nama" placeholder="Masukkan nama barang" required>

        <label for="kategori">Kategori:</label>
        <input type="text" id="kategori" name="kategori" placeholder="Masukkan kategori barang" required>

        <label for="jumlahstok">Jumlah:</label>
        <input type="number" id="jumlahstok" name="jumlahstok" placeholder="Masukkan jumlah barang" required>

        <label for="harga">Harga:</label>
        <input type="number" id="harga" name="harga" placeholder="Masukkan harga barang" required>

        <label for="tanggalmasuk">Tanggal:</label>
        <input type="date" id="tanggalmasuk" name="tanggalmasuk" required>

        <button type="submit" name="tambahbarang">Tambah Barang</button>
    </form>

    <a href="index.php" class="back-link">Kembali ke Daftar Barang</a>
</body>
</html>
