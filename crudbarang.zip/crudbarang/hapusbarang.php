<?php
// Koneksi ke database
include("config.php");

// Periksa apakah parameter ID tersedia
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query untuk menghapus data
    $query = "DELETE FROM tabel_barang WHERE id = $id";
    $result = mysqli_query($mysqli, $query);

    // Cek apakah penghapusan berhasil
    if ($result) {
        echo "
            <script>
                alert('Data berhasil dihapus');
                document.location.href = 'index.php';
            </script>
        ";
    } else {
        echo "
            <script>
                alert('Gagal menghapus data: " . mysqli_error($mysqli) . "');
                document.location.href = 'index.php';
            </script>
        ";
    }
} else {
    // Redirect jika tidak ada parameter ID
    header("Location: index.php");
    exit();
}
?>
