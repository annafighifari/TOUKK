<?php
// Koneksi ke database
include("config.php");

// Periksa apakah parameter ID tersedia
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Ambil data berdasarkan ID
    $query = "SELECT * FROM tabel_barang WHERE id = $id";
    $result = mysqli_query($mysqli, $query);
    $barang = mysqli_fetch_assoc($result);
} else {
    // Redirect jika tidak ada parameter ID
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        form {
            max-width: 400px;
            margin: auto;
            background: #f9f9f9;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input, button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Edit Barang</h1>
    <form action="proseseditbarang.php" method="POST">
        <input type="hidden" name="id" value="<?= $barang['id'] ?>">

        <label for="nama">Nama Barang:</label>
        <input type="text" id="nama" name="nama" value="<?= $barang['nama'] ?>" required>

        <label for="kategori">Kategori:</label>
        <input type="text" id="kategori" name="kategori" value="<?= $barang['kategori'] ?>" required>

        <label for="jumlahstok">Jumlah:</label>
        <input type="number" id="jumlahstok" name="jumlahstok" value="<?= $barang['jumlahstok'] ?>" required>

        <label for="harga">Harga:</label>
        <input type="number" id="harga" name="harga" value="<?= $barang['harga'] ?>" required>

        <label for="tanggalmasuk">Tanggal:</label>
        <input type="date" id="tanggalmasuk" name="tanggalmasuk" value="<?= $barang['tanggalmasuk'] ?>" required>

        <button type="submit" name="updatebarang">Simpan Perubahan</button>
    </form>

    <a href="index.php" class="back-link">Kembali ke Daftar Barang</a>
</body>
</html>
