<?php
    $dbHostName= "localhost";
    $username= "root";
    $password= "";
    $dbName= "dbukk";

    $mysqli = mysqli_connect($dbHostName,$username,$password,$dbName);
    ?>