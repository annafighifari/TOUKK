<?php
// Koneksi ke database
include("config.php");

// Periksa apakah tombol update diklik
if (isset($_POST["updatebarang"])) {
    $id = $_POST["id"];
    $nama = $_POST["nama"];
    $kategori = $_POST["kategori"];
    $jumlahstok = $_POST["jumlahstok"];
    $harga = $_POST["harga"];
    $tanggalmasuk = $_POST["tanggalmasuk"];

    // Query untuk mengupdate data
    $query = "UPDATE tabel_barang SET 
                nama = '$nama', 
                kategori = '$kategori', 
                jumlahstok = '$jumlahstok', 
                harga = '$harga', 
                tanggalmasuk = '$tanggalmasuk' 
              WHERE id = $id";
    $result = mysqli_query($mysqli, $query);

    // Cek apakah update berhasil
    if ($result) {
        echo "
            <script>
                alert('Data berhasil diperbarui');
                document.location.href = 'index.php';
            </script>
        ";
    } else {
        echo "
            <script>
                alert('Gagal memperbarui data: " . mysqli_error($mysqli) . "');
                document.location.href = 'index.php';
            </script>
        ";
    }
} else {
    // Redirect jika file diakses langsung
    header("Location: index.php");
    exit();
}
?>
