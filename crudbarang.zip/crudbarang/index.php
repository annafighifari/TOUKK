<?php
// Koneksi ke database
include("config.php");

// Ambil data dari tabel_barang
$result = mysqli_query($mysqli, "SELECT * FROM tabel_barang");

// Ambil daftar kategori unik dari tabel_barang
$kategori_result = mysqli_query($mysqli, "SELECT DISTINCT kategori FROM tabel_barang");
if (!$kategori_result) {
    die("Query error: " . mysqli_error($mysqli));
}

// Default filter kategori
$filter_kategori = isset($_GET['kategori']) ? $_GET['kategori'] : '';

// Query untuk mengambil data barang berdasarkan filter
$query = "SELECT * FROM tabel_barang";
if (!empty($filter_kategori)) {
    $query .= " WHERE kategori = '$filter_kategori'";
}
$result = mysqli_query($mysqli, $query);
if (!$result) {
    die("Query error: " . mysqli_error($mysqli));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Barang</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        form {
            margin-top: 20px;
        }
    </style>
</head>
<body>
<h1>Daftar Barang</h1>

<div class="filter-container">
    <form method="GET" action="#">
        <label for="kategori">Filter Kategori:</label>
        <select id="kategori" name="kategori">
            <option value="">Semua Kategori</option>
            <?php
            while ($kategori = mysqli_fetch_assoc($kategori_result)) {
                $selected = $filter_kategori == $kategori['kategori'] ? 'selected' : '';
                echo "<option value='" . $kategori['kategori'] . "' $selected>" . $kategori['kategori'] . "</option>";
            }
            ?>
        </select>
        <button type="submit">Tampilkan</button>
    </form>
</div>
    <!-- Tabel Data Barang -->
    <table>
        <a href="tambahbarang.php" class='btn btn-success'>Tambah Barang</a>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Kategori</th>
                <th>Stok</th>
                <th>Harga</th>
                <th>Tanggal</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            while ($barang = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $no++ . "</td>";
                echo "<td>" . $barang['nama'] . "</td>";
                echo "<td>" . $barang['kategori'] . "</td>";
                echo "<td>" . $barang['jumlahstok'] . "</td>";
                echo "<td>" . $barang['harga'] . "</td>";
                echo "<td>" . $barang['tanggalmasuk'] . "</td>";
                echo "<td class='action-buttons'>
                <a href='editbarang.php?id=" . $barang['id'] . "' class='btn btn-warning'>Edit</a>
                <a href='hapusbarang.php?id=" . $barang['id'] . "' class='btn btn-danger' onclick='return confirm(\"Apakah Anda yakin ingin menghapus data ini?\")'>Hapus</a>
              </td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
    <br><br>
    <nav aria-label="Page navigation example">
  <ul class="pagination justify-content-center">
    <li class="page-item disabled">
      <a class="page-link">Previous</a>
    </li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="daftarkategori.php">2</a></li>
    <li class="page-item">
      <a class="page-link" href="daftarkategori.php">Next</a>
    </li>
  </ul>
</nav>