<?php
// Koneksi ke database
include("config.php");

// Ambil data dari tabel_barang
$result = mysqli_query($mysqli, "SELECT * FROM tabel_kategori");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Barang</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        form {
            margin-top: 20px;
        }
    </style>
    </head>
    <h1>Daftar Kategori</h1>
     <!-- Tabel Data Barang -->
     <table>
        <br>
        <a href="tambahkategori.php" class='btn btn-success'>Tambah Kategori</a>
        <thead>
            <tr>
                <th>No</th>
                <th>Kategori</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            while ($nama = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $no++ . "</td>";
                echo "<td>" . $nama['nama'] . "</td>";
                echo "<td class='action-buttons'>
                <a href='hapuskategori.php?id=" . $nama['id'] . "' class='btn btn-danger' onclick='return confirm(\"Apakah Anda yakin ingin menghapus data ini?\")'>Hapus</a>
              </td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
    <br><br>
    <nav aria-label="Page navigation example">
  <ul class="pagination justify-content-center">
    <li class="page-item">
      <a class="page-link" href="index.php">Previous</a>
    </li>
    <li class="page-item"><a class="page-link" href="index.php">1</a></li>
    <li class="page-item"><a class="page-link" href="daftarkategori.php">2</a></li>
    <li class="page-item disabled">
      <a class="page-link">Next</a>
    </li>
  </ul>
</nav>
</html>