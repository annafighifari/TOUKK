<?php
// Koneksi ke database
include("config.php");

// Cek apakah tombol tambah barang diklik
if (isset($_POST["tambahkategori"])) {
    // Ambil data dari form
    $nama_kategori = $_POST["nama_kategori"];
    // Query untuk menambahkan data ke tabel_barang
    $query = "INSERT INTO tabel_kategori (nama) 
              VALUES ('$nama_kategori')";

    // Eksekusi query
    $result = mysqli_query($mysqli, $query);

    // Cek apakah data berhasil ditambahkan
    if ($result) {
        echo "
            <script>
                alert('Berhasil menambahkan data');
                document.location.href = 'daftarkategori.php';
            </script>
        ";
    } else {
        echo "
            <script>
                alert('Gagal menambahkan data: " . mysqli_error($mysqli) . "');
                document.location.href = 'daftarkategori.php';
            </script>
        ";
    }
} else {
    // Redirect ke halaman utama jika akses langsung
    header("Location: daftarkategori.php");
    exit();
}
?>
