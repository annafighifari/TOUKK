<?php
// Koneksi ke database
include("config.php");

// Cek apakah tombol tambah barang diklik
if (isset($_POST["tambahbarang"])) {
    // Ambil data dari form
    $nama = $_POST["nama"];
    $kategori = $_POST["kategori"];
    $jumlahstok = $_POST["jumlahstok"];
    $harga = $_POST["harga"];
    $tanggalmasuk = $_POST["tanggalmasuk"];

    // Query untuk menambahkan data ke tabel_barang
    $query = "INSERT INTO tabel_barang (nama, kategori, jumlahstok, harga, tanggalmasuk) 
              VALUES ('$nama', '$kategori', '$jumlahstok', '$harga', '$tanggalmasuk')";

    // Eksekusi query
    $result = mysqli_query($mysqli, $query);

    // Cek apakah data berhasil ditambahkan
    if ($result) {
        echo "
            <script>
                alert('Berhasil menambahkan data');
                document.location.href = 'index.php';
            </script>
        ";
    } else {
        echo "
            <script>
                alert('Gagal menambahkan data: " . mysqli_error($mysqli) . "');
                document.location.href = 'index.php';
            </script>
        ";
    }
} else {
    // Redirect ke halaman utama jika akses langsung
    header("Location: index.php");
    exit();
}
?>
